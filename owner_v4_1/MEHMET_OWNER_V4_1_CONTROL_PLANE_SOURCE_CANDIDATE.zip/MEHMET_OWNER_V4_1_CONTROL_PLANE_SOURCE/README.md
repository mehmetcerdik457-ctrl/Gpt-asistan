# MEHMET OWNER V4 CONTROL PLANE — SOURCE CANDIDATE

OWNER = MEHMET CERDİK

Bu kaynak, mevcut V3 Core/Bridge hattını sıfırlamaz. V3 imzalı binary'ler korunur. V4 ayrı bir aday kaynak dalıdır.

## Amaç

Telefon üzerinde owner-controlled şu zinciri sağlamak:

GÖR → ANLA → AÇ → DOKUN → KAYDIR → YAZ → DOĞRULA

## V3'ten taşınan güvenlik ilkeleri

- Core ve Bridge ayrı paketlerdir.
- Core→Bridge IPC, signature-level permission ile korunur.
- Bridge çağıran UID/package/signeri doğrular.
- Core ve Bridge beklenen MEHMET GEN2 signer kimliğini pinler.
- Chatbot AI worker için 7B4A signer kimliği korunur.
- Bridge'de INTERNET izni yoktur.
- Emergency stop vardır.
- DISPATCHED ile CONFIRMED ayrı tutulur.
- Audit kaydı ham argüman yerine hash kullanır.

## V4 ekleri

- Accessibility yalnız Chatbot AI packageNames filtresine bağlı değildir; sistem genelini görebilecek teknik yüzey açılmıştır.
- Bunun karşılığında fail-closed `package + signer` onay listesi eklendi.
- İlk varsayılan onaylı hedef: `com.codespaceapps.aichat` + 7B4A signer.
- Diğer uygulamalar Core üzerinden owner tarafından tek tek onaylanır; onay sırasında kurulu signer kaydedilir ve sonraki eylemde yeniden doğrulanır.
- Owner session varsayılan 5 dakika, maksimum 10 dakika. Emergency stop varsayılan olarak açıktır.
- Eylem yüzeyi: screenRead, clickText, typeText, scroll, normalized swipe/dispatchGesture, Back/Home/Recents/Notifications, app launch.
- Ekran okumasında password node'ları `<password>` olarak redakte edilir.
- Gesture/click/global action için mümkün olduğunda snapshot değişimi postcondition olarak kontrol edilir. Değişim kanıtlanmazsa `DISPATCHED` döner; `CONFIRMED` verilmez.
- Vendor PRO/paywall/entitlement bypass kodu yoktur.

## Bilerek eklenmeyenler

- Ağ tabanlı localhost HTTP/MCP server yok. Bridge INTERNET izinsiz kalır.
- Root/ADB/shell yok.
- Otomatik satın alma/abonelik/entitlement müdahalesi yok.
- Gizli/şifreli alan içeriği screen snapshot'a yazılmaz.

## Build durumu

Bu oturumda Android SDK / Gradle build toolchain mevcut olmadığı için kaynak APK'ya derlenmedi. Kaynak statik denetimden geçirildi. İmzalı APK üretildiği iddia edilmemelidir.

Canonical release şartı:

1. Android build toolchain ile `:core:assembleRelease` ve `:bridge:assembleRelease`.
2. Çıkan APK'ların package/version/manifest/dex doğrulaması.
3. Mevcut GEN2 release signing identity ile imzalama.
4. Signer SHA-256'nin `279084...9448` olarak geri okunması.
5. Android gerçek cihaz install gate.
6. Accessibility enablement.
7. Önce screenRead-only smoke test.
8. Sonra Chatbot AI üzerinde kontrollü TYPE/CLICK/SWIPE ve postcondition.
9. Yalnız gerçek cihaz kanıtıyla PHONE_ACTION_PASS / REAL_TASK_PASS.

## Önemli güvenlik notu

`QUERY_ALL_PACKAGES` ve sistem-geneli Accessibility görünürlüğü güçlü yetkilerdir. Bu nedenle Bridge'in ağ erişimi yoktur, paket+signer allowlist ve kısa owner session zorunludur. Production öncesi bu tasarım gerçek cihaz ve adversarial testlerden geçmelidir.
