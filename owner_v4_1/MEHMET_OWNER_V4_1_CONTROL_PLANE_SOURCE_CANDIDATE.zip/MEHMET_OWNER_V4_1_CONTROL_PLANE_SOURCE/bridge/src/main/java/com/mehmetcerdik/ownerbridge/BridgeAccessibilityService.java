package com.mehmetcerdik.ownerbridge;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.content.Intent;
import android.graphics.Path;
import android.graphics.Rect;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.text.InputType;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

public final class BridgeAccessibilityService extends AccessibilityService {
    private static volatile BridgeAccessibilityService INSTANCE;
    private static final int MAX_NODES = 250;
    private static final int MAX_FIELD = 180;
    private static final Set<String> SECRET_SELECTOR_HASHES = new HashSet<>();

    static BridgeAccessibilityService instance() { return INSTANCE; }

    @Override protected void onServiceConnected() {
        super.onServiceConnected(); INSTANCE = this; BridgeSecurity.ensureDefaults(this); BridgeSecurity.failClosedLifecycle(this, "service_connected");
    }
    @Override public void onDestroy() { BridgeSecurity.failClosedLifecycle(this, "service_destroyed"); if (INSTANCE == this) INSTANCE = null; super.onDestroy(); }
    @Override public void onInterrupt() { BridgeSecurity.failClosedLifecycle(this, "service_interrupted"); }
    @Override public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null || event.getPackageName() == null) return;
        BridgeSecurity.prefs(this).edit().putString("last_event_package", event.getPackageName().toString()).putLong("last_event_elapsed", SystemClock.elapsedRealtime()).commit();
    }

    Bundle status() { Bundle b = ok(); b.putString("active_package", activePackage()); b.putBoolean("service_connected", true); return b; }

    Bundle screenRead() {
        AccessibilityNodeInfo root = getRootInActiveWindow(); if (root == null) return fail("NO_ACTIVE_ROOT");
        String pkg = packageName(root); if (!BridgeSecurity.isPackageApproved(this, pkg)) return fail("ACTIVE_PACKAGE_NOT_APPROVED");
        String snapshot = snapshot(root); Bundle b = ok(); b.putString("status", "OBSERVED"); b.putString("package", pkg); b.putString("snapshot", snapshot); b.putString("snapshot_hash", BridgeSecurity.sha256String(snapshot)); return b;
    }

    Bundle clickTextExact(String wanted) {
        if (wanted == null || wanted.trim().isEmpty()) return fail("EMPTY_SELECTOR");
        String expectedPkg = activePackage(); if (!BridgeSecurity.isPackageApproved(this, expectedPkg)) return fail("ACTIVE_PACKAGE_NOT_APPROVED");
        AccessibilityNodeInfo target = findUniqueExact(wanted.trim()); if (target == null) return fail("TARGET_NOT_FOUND_OR_AMBIGUOUS");
        if (!expectedPkg.equals(activePackage())) return fail("PACKAGE_TRANSITION_BEFORE_DISPATCH");
        target = findUniqueExact(wanted.trim()); if (target == null) return fail("STALE_NODE_REACQUIRE_FAILED");
        AccessibilityNodeInfo clickable = nearestClickable(target); if (clickable == null) return fail("TARGET_NOT_CLICKABLE");
        boolean dispatched = clickable.performAction(AccessibilityNodeInfo.ACTION_CLICK); if (!dispatched) return fail("CLICK_DISPATCH_FAILED");
        SystemClock.sleep(250); Bundle b = ok(); b.putString("status", "UI_CHANGED"); b.putBoolean("package_stable", expectedPkg.equals(activePackage())); b.putString("snapshot_hash", currentSnapshotHash()); return b;
    }

    Bundle typeText(String selector, String value, boolean secret) {
        if (value == null) return fail("NULL_TEXT");
        String expectedPkg = activePackage(); if (!BridgeSecurity.isPackageApproved(this, expectedPkg)) return fail("ACTIVE_PACKAGE_NOT_APPROVED");
        AccessibilityNodeInfo target = findUniqueEditable(selector); if (target == null) return fail("EDITABLE_NOT_FOUND_OR_AMBIGUOUS");
        if (!expectedPkg.equals(activePackage())) return fail("PACKAGE_TRANSITION_BEFORE_DISPATCH");
        target = findUniqueEditable(selector); if (target == null) return fail("STALE_NODE_REACQUIRE_FAILED");
        if (secret) SECRET_SELECTOR_HASHES.add(BridgeSecurity.sha256String(nodeLabel(target)));
        Bundle args = new Bundle(); args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, value);
        boolean dispatched = target.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args); if (!dispatched) return fail("SET_TEXT_DISPATCH_FAILED");
        SystemClock.sleep(120); AccessibilityNodeInfo fresh = findUniqueEditable(selector); boolean confirmed = fresh != null && fresh.getText() != null && value.contentEquals(fresh.getText());
        Bundle b = ok(); b.putString("status", confirmed ? "TARGET_POSTCONDITION_CONFIRMED" : "DISPATCHED"); b.putBoolean("confirmed", confirmed); return b;
    }

    Bundle scroll(boolean forward) {
        String expectedPkg = activePackage(); if (!BridgeSecurity.isPackageApproved(this, expectedPkg)) return fail("ACTIVE_PACKAGE_NOT_APPROVED");
        AccessibilityNodeInfo root = getRootInActiveWindow(); if (root == null) return fail("NO_ACTIVE_ROOT");
        List<AccessibilityNodeInfo> nodes = new ArrayList<>(); collectScrollable(root, nodes); if (nodes.size() != 1) return fail(nodes.isEmpty()?"SCROLLABLE_NOT_FOUND":"SCROLLABLE_AMBIGUOUS");
        if (!expectedPkg.equals(activePackage())) return fail("PACKAGE_TRANSITION_BEFORE_DISPATCH");
        String before = currentSnapshotHash(); boolean dispatched = nodes.get(0).performAction(forward ? AccessibilityNodeInfo.ACTION_SCROLL_FORWARD : AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD); if (!dispatched) return fail("SCROLL_DISPATCH_FAILED");
        SystemClock.sleep(300); String after = currentSnapshotHash(); Bundle b = ok(); b.putString("status", !before.equals(after) && !after.isEmpty() ? "UI_CHANGED" : "DISPATCHED"); b.putBoolean("package_stable", expectedPkg.equals(activePackage())); b.putString("snapshot_hash", after); return b;
    }

    Bundle swipe(float sx, float sy, float ex, float ey, long durationMs) {
        String expectedPkg = activePackage(); if (!BridgeSecurity.isPackageApproved(this, expectedPkg)) return fail("ACTIVE_PACKAGE_NOT_APPROVED");
        if (!norm(sx)||!norm(sy)||!norm(ex)||!norm(ey)) return fail("SWIPE_COORDINATE_OUT_OF_RANGE");
        long d = Math.max(100L, Math.min(durationMs <= 0 ? 350L : durationMs, 2000L)); android.util.DisplayMetrics dm = getResources().getDisplayMetrics();
        float x1=sx*dm.widthPixels,y1=sy*dm.heightPixels,x2=ex*dm.widthPixels,y2=ey*dm.heightPixels; String before=currentSnapshotHash();
        if (!expectedPkg.equals(activePackage()) || !BridgeSecurity.isPackageApproved(this, activePackage())) return fail("PACKAGE_TRANSITION_BEFORE_DISPATCH");
        Path path=new Path(); path.moveTo(x1,y1); path.lineTo(x2,y2); GestureDescription gesture=new GestureDescription.Builder().addStroke(new GestureDescription.StrokeDescription(path,0,d)).build();
        CountDownLatch latch=new CountDownLatch(1); final boolean[] completed={false};
        boolean accepted=dispatchGesture(gesture,new GestureResultCallback(){@Override public void onCompleted(GestureDescription g){completed[0]=true;latch.countDown();}@Override public void onCancelled(GestureDescription g){latch.countDown();}},new Handler(Looper.getMainLooper()));
        if(!accepted)return fail("GESTURE_NOT_ACCEPTED"); try{latch.await(2500L,TimeUnit.MILLISECONDS);}catch(InterruptedException e){Thread.currentThread().interrupt();}
        if(!completed[0])return fail("GESTURE_NOT_COMPLETED"); SystemClock.sleep(250); String afterPkg=activePackage(); if(!expectedPkg.equals(afterPkg))return fail("PACKAGE_TRANSITION_AFTER_GESTURE");
        String after=currentSnapshotHash(); Bundle b=ok(); b.putString("status",!before.equals(after)&&!after.isEmpty()?"UI_CHANGED":"GESTURE_COMPLETED"); b.putBoolean("gesture_completed",true); b.putString("snapshot_hash",after); return b;
    }

    Bundle globalAction(String actionName) {
        String expectedPkg=activePackage(); if(!BridgeSecurity.isPackageApproved(this,expectedPkg))return fail("ACTIVE_PACKAGE_NOT_APPROVED");
        int action; String n=actionName==null?"":actionName.trim().toUpperCase(Locale.ROOT);
        switch(n){case"BACK":action=GLOBAL_ACTION_BACK;break;case"HOME":action=GLOBAL_ACTION_HOME;break;case"RECENTS":action=GLOBAL_ACTION_RECENTS;break;case"NOTIFICATIONS":action=GLOBAL_ACTION_NOTIFICATIONS;break;default:return fail("UNKNOWN_GLOBAL_ACTION");}
        if(!expectedPkg.equals(activePackage())||!BridgeSecurity.isPackageApproved(this,activePackage()))return fail("PACKAGE_TRANSITION_BEFORE_GLOBAL_ACTION");
        String before=currentSnapshotHash(); boolean dispatched=performGlobalAction(action); if(!dispatched)return fail("GLOBAL_ACTION_DISPATCH_FAILED"); SystemClock.sleep(400); String after=currentSnapshotHash();
        Bundle b=ok(); b.putString("status",!before.equals(after)||!expectedPkg.equals(activePackage())?"UI_CHANGED":"DISPATCHED"); b.putString("snapshot_hash",after); return b;
    }

    Bundle launchApp(String pkg) {
        if(!BridgeSecurity.isPackageApproved(this,pkg))return fail("PACKAGE_NOT_APPROVED"); Intent i=getPackageManager().getLaunchIntentForPackage(pkg); if(i==null)return fail("NO_LAUNCH_INTENT"); i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try{startActivity(i);}catch(Throwable t){return fail("LAUNCH_FAILED");}
        long end=SystemClock.elapsedRealtime()+3000L; while(SystemClock.elapsedRealtime()<end){if(pkg.equals(activePackage())){Bundle b=ok();b.putString("status","TARGET_POSTCONDITION_CONFIRMED");b.putBoolean("confirmed",true);return b;}SystemClock.sleep(100);}
        Bundle b=ok();b.putString("status","DISPATCHED");b.putBoolean("confirmed",false);return b;
    }

    Bundle verifyPostcondition(String expectedPackage, String expectedText) {
        String pkg=activePackage(); if(expectedPackage!=null&&!expectedPackage.isEmpty()&&!expectedPackage.equals(pkg))return fail("POSTCONDITION_PACKAGE_MISMATCH");
        AccessibilityNodeInfo root=getRootInActiveWindow(); if(root==null)return fail("NO_ACTIVE_ROOT"); String snap=snapshot(root);
        if(expectedText!=null&&!expectedText.isEmpty()&&!snap.toLowerCase(Locale.ROOT).contains(expectedText.toLowerCase(Locale.ROOT)))return fail("POSTCONDITION_TEXT_NOT_FOUND");
        Bundle b=ok();b.putString("status","TARGET_POSTCONDITION_CONFIRMED");b.putString("package",pkg);b.putString("snapshot_hash",BridgeSecurity.sha256String(snap));return b;
    }

    private AccessibilityNodeInfo findUniqueExact(String wanted){AccessibilityNodeInfo root=getRootInActiveWindow();if(root==null)return null;List<AccessibilityNodeInfo> nodes=new ArrayList<>();collectExactLabel(root,wanted,nodes);return nodes.size()==1?nodes.get(0):null;}
    private AccessibilityNodeInfo findUniqueEditable(String selector){AccessibilityNodeInfo root=getRootInActiveWindow();if(root==null)return null;List<AccessibilityNodeInfo> nodes=new ArrayList<>();collectEditable(root,nodes);if(selector==null||selector.trim().isEmpty())return nodes.size()==1?nodes.get(0):null;String s=selector.trim();List<AccessibilityNodeInfo> filtered=new ArrayList<>();for(AccessibilityNodeInfo n:nodes)if(nodeLabel(n).equalsIgnoreCase(s))filtered.add(n);return filtered.size()==1?filtered.get(0):null;}
    private String activePackage(){AccessibilityNodeInfo root=getRootInActiveWindow();return root==null?"":packageName(root);} private String currentSnapshotHash(){AccessibilityNodeInfo root=getRootInActiveWindow();return root==null?"":BridgeSecurity.sha256String(snapshot(root));}
    private String packageName(AccessibilityNodeInfo root){CharSequence p=root.getPackageName();return p==null?"":p.toString();} private static boolean norm(float v){return v>=0f&&v<=1f;}
    private AccessibilityNodeInfo nearestClickable(AccessibilityNodeInfo n){AccessibilityNodeInfo cur=n;for(int i=0;i<5&&cur!=null;i++){if(cur.isClickable()&&cur.isEnabled())return cur;cur=cur.getParent();}return null;}
    private void collectExactLabel(AccessibilityNodeInfo n,String wanted,List<AccessibilityNodeInfo>out){if(n==null||out.size()>8)return;if(n.isVisibleToUser()&&nodeLabel(n).equalsIgnoreCase(wanted))out.add(n);for(int i=0;i<n.getChildCount();i++)collectExactLabel(n.getChild(i),wanted,out);}
    private void collectEditable(AccessibilityNodeInfo n,List<AccessibilityNodeInfo>out){if(n==null||out.size()>16)return;if(n.isVisibleToUser()&&n.isEnabled()&&n.isEditable())out.add(n);for(int i=0;i<n.getChildCount();i++)collectEditable(n.getChild(i),out);}
    private void collectScrollable(AccessibilityNodeInfo n,List<AccessibilityNodeInfo>out){if(n==null||out.size()>16)return;if(n.isVisibleToUser()&&n.isEnabled()&&n.isScrollable())out.add(n);for(int i=0;i<n.getChildCount();i++)collectScrollable(n.getChild(i),out);}
    private String snapshot(AccessibilityNodeInfo root){StringBuilder sb=new StringBuilder();int[]count={0};appendNode(root,sb,count,0);return sb.toString();}
    private void appendNode(AccessibilityNodeInfo n,StringBuilder sb,int[]count,int depth){if(n==null||count[0]>=MAX_NODES)return;int idx=count[0]++;Rect r=new Rect();n.getBoundsInScreen(r);boolean secret=isSensitiveNode(n);String text=secret?"<redacted>":clip(cs(n.getText()));String desc=secret?"<redacted>":clip(cs(n.getContentDescription()));String hint=secret?"<redacted>":clip(cs(n.getHintText()));String id=clip(n.getViewIdResourceName());String clazz=clip(cs(n.getClassName()));sb.append(idx).append('|').append(depth).append("|text=").append(escape(text)).append("|desc=").append(escape(desc)).append("|hint=").append(escape(hint)).append("|id=").append(escape(id)).append("|class=").append(escape(clazz)).append("|click=").append(n.isClickable()).append("|edit=").append(n.isEditable()).append("|scroll=").append(n.isScrollable()).append("|bounds=").append(r.left).append(',').append(r.top).append(',').append(r.right).append(',').append(r.bottom).append('\n');for(int i=0;i<n.getChildCount()&&count[0]<MAX_NODES;i++)appendNode(n.getChild(i),sb,count,depth+1);}
    private boolean isSensitiveNode(AccessibilityNodeInfo n){if(n==null)return false;if(n.isPassword())return true;int it=n.getInputType();int variation=it&InputType.TYPE_MASK_VARIATION;if(variation==InputType.TYPE_TEXT_VARIATION_PASSWORD||variation==InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD||variation==InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD||variation==InputType.TYPE_NUMBER_VARIATION_PASSWORD)return true;String meta=(cs(n.getHintText())+" "+cs(n.getContentDescription())+" "+n.getViewIdResourceName()+" "+nodeLabelRaw(n)).toLowerCase(Locale.ROOT);String[]keys={"password","parola","şifre","sifre","pin","otp","cvv","cvc","token","api key","apikey","recovery","kurtarma","seed","secret","gizli","verification code","doğrulama kod"};for(String k:keys)if(meta.contains(k))return true;return SECRET_SELECTOR_HASHES.contains(BridgeSecurity.sha256String(nodeLabelRaw(n)));}
    private String nodeLabel(AccessibilityNodeInfo n){return isSensitiveNode(n)?"":nodeLabelRaw(n);} private String nodeLabelRaw(AccessibilityNodeInfo n){if(n==null)return"";String t=cs(n.getText()).trim();if(!t.isEmpty())return t;String d=cs(n.getContentDescription()).trim();if(!d.isEmpty())return d;return cs(n.getHintText()).trim();}
    private static String cs(CharSequence s){return s==null?"":s.toString();} private static String clip(String s){return s==null?"":(s.length()<=MAX_FIELD?s:s.substring(0,MAX_FIELD));} private static String escape(String s){return s.replace("\\","\\\\").replace("\n","\\n").replace("\r","\\r").replace("|","\\|");}
    private Bundle ok(){Bundle b=new Bundle();b.putBoolean("ok",true);return b;} private Bundle fail(String reason){Bundle b=new Bundle();b.putBoolean("ok",false);b.putString("status","FAILED");b.putString("failure",reason);return b;}
}
