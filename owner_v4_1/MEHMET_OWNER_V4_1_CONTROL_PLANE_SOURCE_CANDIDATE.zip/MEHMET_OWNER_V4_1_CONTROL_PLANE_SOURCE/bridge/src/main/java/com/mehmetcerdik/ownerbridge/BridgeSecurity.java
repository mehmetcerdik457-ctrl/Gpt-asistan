package com.mehmetcerdik.ownerbridge;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.pm.Signature;
import android.content.pm.SigningInfo;
import android.content.Intent;
import android.os.Build;
import android.os.SystemClock;
import android.provider.Settings;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;

final class BridgeSecurity {
    static final String CORE_PACKAGE = "com.mehmetcerdik.ownerai";
    static final String CORE_SIGNER = "279084a36b7c17a1663bfba5fe1c5bdac974f8ef4ce56b21000d882493e39448";
    static final String WORKER_PACKAGE = "com.codespaceapps.aichat";
    static final String WORKER_SIGNER = "7b4a4b483ad4fdfa7bcab3c4ba9fd5a0461cab208fc7120a4d8d2f4901b3a097";
    static final long MAX_ARM_MS = 10 * 60 * 1000L;
    static final long DEFAULT_ARM_MS = 5 * 60 * 1000L;
    static final long MAX_CREDENTIAL_PROOF_AGE_MS = 15_000L;

    private static final String PREFS = "mehm_owner_bridge_state";
    private static final String KEY_APPROVED = "approved_package_signers";
    private static final String KEY_EMERGENCY = "emergency_stop";
    private static final String KEY_AUDIT_SEQ = "audit_seq";
    private static final String KEY_AUDIT_HASH = "audit_hash";
    private static final String KEY_AUDIT_SEGMENT = "audit_segment";
    private static final long MAX_AUDIT_BYTES = 128 * 1024L;
    private static final String PROCESS_ID = UUID.randomUUID().toString();
    private static volatile long armedUntilElapsed = 0L;
    private static volatile String sessionId = "";

    private BridgeSecurity() {}

    static SharedPreferences prefs(Context c) { return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE); }

    static void ensureDefaults(Context c) {
        SharedPreferences p = prefs(c);
        Set<String> current = p.getStringSet(KEY_APPROVED, null);
        if (current == null) {
            HashSet<String> s = new HashSet<>();
            s.add(WORKER_PACKAGE + "|" + WORKER_SIGNER);
            p.edit().putStringSet(KEY_APPROVED, s).commit();
        }
        if (!p.contains(KEY_EMERGENCY)) p.edit().putBoolean(KEY_EMERGENCY, true).commit();
    }

    static void failClosedLifecycle(Context c, String reason) {
        armedUntilElapsed = 0L;
        sessionId = "";
        prefs(c).edit().putBoolean(KEY_EMERGENCY, true).commit();
        audit(c, "LIFECYCLE_FAIL_CLOSED", "CONFIRMED", sha256String(reason), safe(reason));
    }

    static String getSigner(Context c, String pkg) {
        try {
            PackageManager pm = c.getPackageManager();
            Signature[] sigs;
            if (Build.VERSION.SDK_INT >= 28) {
                PackageInfo pi = pm.getPackageInfo(pkg, PackageManager.GET_SIGNING_CERTIFICATES);
                SigningInfo si = pi.signingInfo;
                if (si == null) return null;
                sigs = si.getApkContentsSigners();
            } else {
                @SuppressWarnings("deprecation") PackageInfo pi = pm.getPackageInfo(pkg, PackageManager.GET_SIGNATURES);
                @SuppressWarnings("deprecation") Signature[] legacy = pi.signatures;
                sigs = legacy;
            }
            if (sigs == null || sigs.length != 1) return null;
            return sha256Bytes(sigs[0].toByteArray());
        } catch (Throwable t) { return null; }
    }

    static boolean verifyCore(Context c) {
        String s = getSigner(c, CORE_PACKAGE);
        return s != null && CORE_SIGNER.equalsIgnoreCase(s);
    }

    static boolean isArmed(Context c) {
        if (prefs(c).getBoolean(KEY_EMERGENCY, true)) return false;
        long now = SystemClock.elapsedRealtime();
        boolean armed = armedUntilElapsed > now && !sessionId.isEmpty();
        if (!armed) {
            armedUntilElapsed = 0L;
            sessionId = "";
            prefs(c).edit().putBoolean(KEY_EMERGENCY, true).commit();
        }
        return armed;
    }

    static long remainingArmMs(Context c) {
        return isArmed(c) ? Math.max(0L, armedUntilElapsed - SystemClock.elapsedRealtime()) : 0L;
    }

    static long arm(Context c, long requestedMs, long credentialProofElapsed) {
        long now = SystemClock.elapsedRealtime();
        if (credentialProofElapsed <= 0 || credentialProofElapsed > now || now - credentialProofElapsed > MAX_CREDENTIAL_PROOF_AGE_MS) return -1L;
        long ttl = requestedMs <= 0 ? DEFAULT_ARM_MS : Math.min(requestedMs, MAX_ARM_MS);
        sessionId = UUID.randomUUID().toString();
        armedUntilElapsed = now + ttl;
        prefs(c).edit().putBoolean(KEY_EMERGENCY, false).commit();
        if (!audit(c, "ARM", "TARGET_POSTCONDITION_CONFIRMED", sha256String("ttl=" + ttl), "")) {
            stopNoAudit(c);
            return -1L;
        }
        return ttl;
    }

    static void stop(Context c) {
        stopNoAudit(c);
        audit(c, "EMERGENCY_STOP", "TARGET_POSTCONDITION_CONFIRMED", "", "");
    }

    private static void stopNoAudit(Context c) {
        armedUntilElapsed = 0L;
        sessionId = "";
        prefs(c).edit().putBoolean(KEY_EMERGENCY, true).commit();
    }

    static boolean isEmergencyStopped(Context c) { return prefs(c).getBoolean(KEY_EMERGENCY, true); }

    static boolean preActionGate(Context c, String action, String targetDigest) {
        if (!isArmed(c) || isEmergencyStopped(c)) return false;
        if (!verifyAuditIntegrity(c)) {
            stopNoAudit(c);
            return false;
        }
        if (!audit(c, "PRE_" + action, "DISPATCHED", targetDigest, "")) {
            stopNoAudit(c);
            return false;
        }
        return true;
    }

    static String approveInstalledPackage(Context c, String pkg) {
        if (!validPackageName(pkg)) return null;
        String signer = getSigner(c, pkg);
        if (signer == null) return null;
        HashSet<String> set = new HashSet<>(prefs(c).getStringSet(KEY_APPROVED, new HashSet<>()));
        set.removeIf(v -> v.startsWith(pkg + "|"));
        set.add(pkg + "|" + signer.toLowerCase(Locale.ROOT));
        if (!prefs(c).edit().putStringSet(KEY_APPROVED, set).commit()) return null;
        audit(c, "APPROVE_PACKAGE", "TARGET_POSTCONDITION_CONFIRMED", sha256String(pkg + "|" + signer), "");
        return signer;
    }

    static String listApprovedPackages(Context c) {
        ArrayList<String> values = new ArrayList<>(prefs(c).getStringSet(KEY_APPROVED, new HashSet<>()));
        Collections.sort(values);
        return joinLines(values);
    }

    static boolean revokePackage(Context c, String pkg) {
        if (!validPackageName(pkg) || WORKER_PACKAGE.equals(pkg)) return false;
        HashSet<String> set = new HashSet<>(prefs(c).getStringSet(KEY_APPROVED, new HashSet<>()));
        boolean changed = set.removeIf(v -> v.startsWith(pkg + "|"));
        if (changed && prefs(c).edit().putStringSet(KEY_APPROVED, set).commit()) {
            audit(c, "REVOKE_PACKAGE", "TARGET_POSTCONDITION_CONFIRMED", sha256String(pkg), "");
            return true;
        }
        return false;
    }

    static int revokeAllNonDefaultPackages(Context c) {
        Set<String> old = prefs(c).getStringSet(KEY_APPROVED, new HashSet<>());
        int removed = 0;
        HashSet<String> keep = new HashSet<>();
        for (String v : old) {
            if (v.equals(WORKER_PACKAGE + "|" + WORKER_SIGNER)) keep.add(v); else removed++;
        }
        if (!prefs(c).edit().putStringSet(KEY_APPROVED, keep).commit()) return -1;
        audit(c, "REVOKE_ALL_NON_DEFAULT", "TARGET_POSTCONDITION_CONFIRMED", sha256String("removed=" + removed), "");
        return removed;
    }

    static boolean isPackageApproved(Context c, String pkg) {
        if (!validPackageName(pkg)) return false;
        String signer = getSigner(c, pkg);
        if (signer == null) return false;
        Set<String> set = prefs(c).getStringSet(KEY_APPROVED, new HashSet<>());
        return set.contains(pkg + "|" + signer.toLowerCase(Locale.ROOT));
    }

    static String packageDetails(Context c, String pkg) {
        if (!validPackageName(pkg)) return "";
        try {
            PackageManager pm = c.getPackageManager();
            ApplicationInfo ai = pm.getApplicationInfo(pkg, 0);
            String label = String.valueOf(pm.getApplicationLabel(ai));
            String signer = getSigner(c, pkg);
            return "APP LABEL=" + safe(label) + "\nPACKAGE=" + pkg + "\nSIGNER SHA256=" + (signer == null ? "UNKNOWN" : signer);
        } catch (Throwable t) { return ""; }
    }

    static String listLaunchablePackages(Context c) {
        try {
            Intent i = new Intent(Intent.ACTION_MAIN); i.addCategory(Intent.CATEGORY_LAUNCHER);
            List<ResolveInfo> ris = c.getPackageManager().queryIntentActivities(i, 0);
            ArrayList<String> lines = new ArrayList<>();
            for (ResolveInfo ri : ris) {
                if (ri.activityInfo == null || ri.activityInfo.applicationInfo == null) continue;
                String pkg = ri.activityInfo.packageName;
                String label = String.valueOf(ri.loadLabel(c.getPackageManager()));
                lines.add(safe(label) + " | " + pkg);
            }
            Collections.sort(lines);
            return joinLines(lines);
        } catch (Throwable t) { return ""; }
    }

    static boolean validPackageName(String pkg) {
        return pkg != null && pkg.length() >= 3 && pkg.length() <= 255 && pkg.matches("[A-Za-z][A-Za-z0-9_]*(\\.[A-Za-z0-9_]+)+");
    }

    static String sha256String(String s) { return sha256Bytes((s == null ? "" : s).getBytes(StandardCharsets.UTF_8)); }

    static String sha256Bytes(byte[] data) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] out = md.digest(data);
            StringBuilder sb = new StringBuilder(out.length * 2);
            for (byte b : out) sb.append(String.format(Locale.ROOT, "%02x", b & 0xff));
            return sb.toString();
        } catch (Throwable t) { return "HASH_ERROR"; }
    }

    static void saveState(Context c, String action, String status, String resultHash, String failure) {
        prefs(c).edit().putString("last_action", safe(action)).putString("status", safe(status)).putString("result", safe(resultHash)).putString("failure", safe(failure)).commit();
        audit(c, action, status, resultHash, failure);
    }

    static boolean audit(Context c, String action, String status, String resultDigest, String failure) {
        try {
            rotateIfNeeded(c);
            SharedPreferences p = prefs(c);
            long seq = p.getLong(KEY_AUDIT_SEQ, 0L) + 1L;
            String prev = p.getString(KEY_AUDIT_HASH, "GENESIS");
            int segment = p.getInt(KEY_AUDIT_SEGMENT, 0);
            String payload = "seq=" + seq + "|segment=" + segment + "|elapsed=" + SystemClock.elapsedRealtime()
                    + "|boot=" + bootCount(c) + "|process=" + PROCESS_ID + "|session=" + safe(sessionId)
                    + "|action=" + safe(action) + "|status=" + safe(status)
                    + "|result_hash=" + safe(resultDigest) + "|failure=" + safe(failure) + "|prev=" + prev;
            String entry = sha256String(payload);
            String line = payload + "|entry=" + entry + "\n";
            try (FileOutputStream fos = c.openFileOutput("owner_audit.log", Context.MODE_APPEND)) { fos.write(line.getBytes(StandardCharsets.UTF_8)); fos.getFD().sync(); }
            boolean ok = p.edit().putLong(KEY_AUDIT_SEQ, seq).putString(KEY_AUDIT_HASH, entry).putString("last_audit", line).commit();
            return ok;
        } catch (Throwable t) { return false; }
    }

    static boolean verifyAuditIntegrity(Context c) {
        try {
            File current = new File(c.getFilesDir(), "owner_audit.log");
            if (!current.exists() || current.length() == 0) return true;
            String expectedPrev = null;
            long lastSeq = -1;
            String lastEntry = "";
            try (BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(current), StandardCharsets.UTF_8))) {
                String line;
                while ((line = br.readLine()) != null) {
                    int ep = line.lastIndexOf("|entry=");
                    if (ep <= 0) return false;
                    String payload = line.substring(0, ep);
                    String entry = line.substring(ep + 7);
                    if (!sha256String(payload).equals(entry)) return false;
                    String prev = field(payload, "prev");
                    long seq = Long.parseLong(field(payload, "seq"));
                    if (expectedPrev != null && !expectedPrev.equals(prev)) return false;
                    if (lastSeq >= 0 && seq != lastSeq + 1) return false;
                    expectedPrev = entry; lastEntry = entry; lastSeq = seq;
                }
            }
            SharedPreferences p = prefs(c);
            return lastSeq == p.getLong(KEY_AUDIT_SEQ, 0L) && lastEntry.equals(p.getString(KEY_AUDIT_HASH, ""));
        } catch (Throwable t) { return false; }
    }

    private static void rotateIfNeeded(Context c) throws Exception {
        File current = new File(c.getFilesDir(), "owner_audit.log");
        if (!current.exists() || current.length() < MAX_AUDIT_BYTES) return;
        File prev = new File(c.getFilesDir(), "owner_audit.prev");
        if (prev.exists() && !prev.delete()) throw new IllegalStateException("AUDIT_PREV_DELETE_FAILED");
        if (!current.renameTo(prev)) throw new IllegalStateException("AUDIT_ROTATE_FAILED");
        SharedPreferences p = prefs(c);
        int segment = p.getInt(KEY_AUDIT_SEGMENT, 0) + 1;
        if (!p.edit().putInt(KEY_AUDIT_SEGMENT, segment).putLong(KEY_AUDIT_SEQ, 0L).putString(KEY_AUDIT_HASH, "GENESIS").commit()) throw new IllegalStateException("AUDIT_STATE_RESET_FAILED");
    }

    private static int bootCount(Context c) {
        try { return Settings.Global.getInt(c.getContentResolver(), Settings.Global.BOOT_COUNT); } catch (Throwable t) { return -1; }
    }

    private static String field(String payload, String key) {
        String needle = key + "="; int start = payload.indexOf(needle); if (start < 0) return ""; start += needle.length(); int end = payload.indexOf('|', start); return end < 0 ? payload.substring(start) : payload.substring(start, end);
    }

    private static String joinLines(List<String> v) { StringBuilder sb = new StringBuilder(); for (String s : v) sb.append(s).append('\n'); return sb.toString(); }
    private static String safe(String s) { return s == null ? "" : s.replace("\n", " ").replace("\r", " ").replace("|", "/"); }
}
