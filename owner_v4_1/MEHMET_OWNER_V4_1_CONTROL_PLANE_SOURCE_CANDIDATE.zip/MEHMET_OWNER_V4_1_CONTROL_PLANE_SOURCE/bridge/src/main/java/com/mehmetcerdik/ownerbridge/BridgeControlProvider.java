package com.mehmetcerdik.ownerbridge;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Binder;
import android.os.Bundle;

public final class BridgeControlProvider extends ContentProvider {
    @Override public boolean onCreate(){Context c=getContext();if(c!=null)BridgeSecurity.ensureDefaults(c);return true;}
    @Override public String getType(Uri uri){return null;} @Override public Cursor query(Uri uri,String[]p,String s,String[]a,String o){return null;} @Override public Uri insert(Uri uri,ContentValues v){return null;} @Override public int delete(Uri uri,String s,String[]a){return 0;} @Override public int update(Uri uri,ContentValues v,String s,String[]a){return 0;}

    @Override public Bundle call(String method,String arg,Bundle extras){
        Context c=getContext();if(c==null)return fail("NO_CONTEXT");if(!authCaller(c))return fail("CALLER_UID_PACKAGE_SIGNER_AUTH_FAILED");if(method==null)return fail("NULL_METHOD");BridgeAccessibilityService svc=BridgeAccessibilityService.instance();
        switch(method){
            case"status":return statusBundle(c,svc);
            case"arm":{long ttl=extras==null?BridgeSecurity.DEFAULT_ARM_MS:extras.getLong("ttl_ms",BridgeSecurity.DEFAULT_ARM_MS);long proof=extras==null?0L:extras.getLong("credential_proof_elapsed",0L);long remaining=BridgeSecurity.arm(c,ttl,proof);if(remaining<0)return fail("DEVICE_CREDENTIAL_PROOF_INVALID_OR_STALE");Bundle b=statusBundle(c,svc);b.putLong("remaining_ms",remaining);return b;}
            case"stop":BridgeSecurity.stop(c);return statusBundle(c,svc);
            case"listLaunchablePackages":if(!BridgeSecurity.isArmed(c))return fail("NOT_ARMED");return text("packages",BridgeSecurity.listLaunchablePackages(c));
            case"packageDetails":if(!BridgeSecurity.isArmed(c))return fail("NOT_ARMED");return text("details",BridgeSecurity.packageDetails(c,str(extras,"package")));
            case"approvePackage":if(!BridgeSecurity.isArmed(c))return fail("NOT_ARMED");{String pkg=str(extras,"package");String signer=BridgeSecurity.approveInstalledPackage(c,pkg);if(signer==null)return fail("PACKAGE_APPROVAL_FAILED");Bundle b=ok();b.putString("status","TARGET_POSTCONDITION_CONFIRMED");b.putString("package",pkg);b.putString("signer",signer);return b;}
            case"listApprovedPackages":if(!BridgeSecurity.isArmed(c))return fail("NOT_ARMED");return text("approved",BridgeSecurity.listApprovedPackages(c));
            case"revokePackage":if(!BridgeSecurity.isArmed(c))return fail("NOT_ARMED");{String pkg=str(extras,"package");if(!BridgeSecurity.revokePackage(c,pkg))return fail("REVOKE_FAILED_OR_DEFAULT_PROTECTED");return confirmed();}
            case"revokeAllNonDefaultPackages":if(!BridgeSecurity.isArmed(c))return fail("NOT_ARMED");{int n=BridgeSecurity.revokeAllNonDefaultPackages(c);if(n<0)return fail("REVOKE_ALL_FAILED");Bundle b=confirmed();b.putInt("removed",n);return b;}
            case"verifyAudit":{Bundle b=ok();boolean v=BridgeSecurity.verifyAuditIntegrity(c);b.putBoolean("integrity",v);b.putString("status",v?"TARGET_POSTCONDITION_CONFIRMED":"FAILED");return b;}
        }
        if(!ready(c,svc))return fail("BRIDGE_NOT_READY");
        String digest=BridgeSecurity.sha256String(method+"|"+(extras==null?"":extras.keySet().toString()));if(!BridgeSecurity.preActionGate(c,method,digest))return fail("PRE_ACTION_SECURITY_OR_AUDIT_GATE_FAILED");
        Bundle r;
        switch(method){
            case"screenRead":r=svc.screenRead();break;
            case"clickText":r=svc.clickTextExact(str(extras,"text"));break;
            case"typeText":r=svc.typeText(str(extras,"selector"),str(extras,"text"),extras!=null&&extras.getBoolean("secret",false));break;
            case"scroll":r=svc.scroll(extras==null||extras.getBoolean("forward",true));break;
            case"swipe":if(extras==null)return fail("MISSING_EXTRAS");r=svc.swipe(extras.getFloat("sx",-1f),extras.getFloat("sy",-1f),extras.getFloat("ex",-1f),extras.getFloat("ey",-1f),extras.getLong("duration_ms",350L));break;
            case"globalAction":r=svc.globalAction(str(extras,"action"));break;
            case"launchApp":r=svc.launchApp(str(extras,"package"));break;
            case"verifyPostcondition":r=svc.verifyPostcondition(str(extras,"expected_package"),str(extras,"expected_text"));break;
            default:return fail("UNKNOWN_OR_INVALID_METHOD");
        }
        return record(c,method,r);
    }

    private boolean ready(Context c,BridgeAccessibilityService svc){return svc!=null&&BridgeSecurity.isArmed(c)&&!BridgeSecurity.isEmergencyStopped(c);}    
    private Bundle record(Context c,String action,Bundle result){if(result==null)result=fail("NULL_RESULT");String status=result.getString("status",result.getBoolean("ok",false)?"OBSERVED":"FAILED");String failure=result.getString("failure","");String rh=result.getString("snapshot_hash","");BridgeSecurity.saveState(c,action,status,BridgeSecurity.sha256String(rh+"|"+status),failure);return result;}
    private boolean authCaller(Context c){int uid=Binder.getCallingUid();PackageManager pm=c.getPackageManager();String[]pkgs=pm.getPackagesForUid(uid);if(pkgs==null||pkgs.length!=1)return false;if(!BridgeSecurity.CORE_PACKAGE.equals(pkgs[0]))return false;return BridgeSecurity.verifyCore(c);}
    private Bundle statusBundle(Context c,BridgeAccessibilityService svc){Bundle b=ok();b.putBoolean("core_ok",BridgeSecurity.verifyCore(c));b.putBoolean("service_connected",svc!=null);b.putBoolean("armed",BridgeSecurity.isArmed(c));b.putBoolean("emergency_stop",BridgeSecurity.isEmergencyStopped(c));b.putLong("remaining_ms",BridgeSecurity.remainingArmMs(c));b.putString("status",BridgeSecurity.prefs(c).getString("status","OBSERVED"));b.putString("failure",BridgeSecurity.prefs(c).getString("failure",""));b.putString("last_action",BridgeSecurity.prefs(c).getString("last_action",""));b.putString("last_audit",BridgeSecurity.prefs(c).getString("last_audit",""));if(svc!=null)b.putAll(svc.status());return b;}
    private static String str(Bundle b,String k){return b==null?null:b.getString(k);} private Bundle text(String key,String value){Bundle b=ok();b.putString("status","OBSERVED");b.putString(key,value==null?"":value);return b;} private Bundle confirmed(){Bundle b=ok();b.putString("status","TARGET_POSTCONDITION_CONFIRMED");return b;} private Bundle ok(){Bundle b=new Bundle();b.putBoolean("ok",true);return b;} private Bundle fail(String reason){Bundle b=new Bundle();b.putBoolean("ok",false);b.putString("status","FAILED");b.putString("failure",reason);return b;}
}
