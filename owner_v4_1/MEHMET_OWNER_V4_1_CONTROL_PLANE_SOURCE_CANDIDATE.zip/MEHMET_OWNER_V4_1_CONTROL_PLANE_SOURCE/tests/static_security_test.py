#!/usr/bin/env python3
from pathlib import Path
import re, sys, hashlib
R=Path(__file__).resolve().parents[1]
core_manifest=(R/'core/src/main/AndroidManifest.xml').read_text()
bridge_manifest=(R/'bridge/src/main/AndroidManifest.xml').read_text()
acc=(R/'bridge/src/main/res/xml/accessibility_service_config.xml').read_text()
sec=(R/'bridge/src/main/java/com/mehmetcerdik/ownerbridge/BridgeSecurity.java').read_text()
svc=(R/'bridge/src/main/java/com/mehmetcerdik/ownerbridge/BridgeAccessibilityService.java').read_text()
prov=(R/'bridge/src/main/java/com/mehmetcerdik/ownerbridge/BridgeControlProvider.java').read_text()
client=(R/'core/src/main/java/com/mehmetcerdik/ownerai/BridgeClient.java').read_text()
main=(R/'core/src/main/java/com/mehmetcerdik/ownerai/MainActivity.java').read_text()

def req(x,msg):
    if not x: raise AssertionError(msg)

# identity / separation
req("com.mehmetcerdik.ownerai" in core_manifest, 'core package missing')
req("com.mehmetcerdik.ownerbridge" in bridge_manifest, 'bridge package missing')
req('protectionLevel="signature"' in core_manifest, 'signature permission missing')
req('android:permission="com.mehmetcerdik.ownerai.permission.BRIDGE"' in bridge_manifest, 'provider protection missing')
req('android.permission.BIND_ACCESSIBILITY_SERVICE' in bridge_manifest, 'accessibility bind permission missing')
req('android.permission.INTERNET' not in bridge_manifest, 'bridge must have no INTERNET permission')
req('Socket' not in svc+prov+sec and 'ServerSocket' not in svc+prov+sec and 'HttpServer' not in svc+prov+sec, 'network server code found')

# full-phone capability is gated by local approval/session; not blanket auto-action
req('android:canPerformGestures="true"' in acc, 'gesture capability missing')
req('android:packageNames=' not in acc, 'accessibility config still hard-scoped to worker')
req('QUERY_ALL_PACKAGES' in bridge_manifest, 'broad package visibility not declared')
req('approved_package_signers' in sec, 'package+signer allowlist missing')
req('isPackageApproved' in sec, 'package approval verification missing')
req('approveInstalledPackage' in sec, 'owner package approval flow missing')
req('CORE_SIGNER' in sec and '279084a36b7c17a1663bfba5fe1c5bdac974f8ef4ce56b21000d882493e39448' in sec, 'core signer pin missing')
req('WORKER_SIGNER' in sec and '7b4a4b483ad4fdfa7bcab3c4ba9fd5a0461cab208fc7120a4d8d2f4901b3a097' in sec, 'worker signer pin missing')
req('EXPECTED_SIGNER' in client and '279084a36b7c17a1663bfba5fe1c5bdac974f8ef4ce56b21000d882493e39448' in client, 'bridge signer pin missing')

# owner session + emergency stop
for token in ['armed_until','emergency_stop','MAX_ARM_MS','DEFAULT_ARM_MS','isArmed','stop']:
    req(token in sec, f'missing owner session control {token}')
req('NOT_ARMED_OR_EMERGENCY_STOP' in prov, 'arm gate missing for package approval')
req('ready(c, svc)' in prov, 'action arm/service gate missing')

# action surface
for method in ['screenRead','clickText','typeText','scroll','swipe','globalAction','launchApp','approvePackage','arm','stop']:
    req(f'case "{method}"' in prov, f'provider method missing {method}')
for token in ['getRootInActiveWindow','ACTION_CLICK','ACTION_SET_TEXT','ACTION_SCROLL_FORWARD','dispatchGesture','performGlobalAction','getLaunchIntentForPackage']:
    req(token in svc, f'android action implementation missing {token}')
for action in ['BACK','HOME','RECENTS','NOTIFICATIONS']:
    req(f'case "{action}"' in svc, f'global action missing {action}')

# screen privacy + fail-closed selector rules
req('n.isPassword() ? "<password>"' in svc, 'password redaction missing')
for failure in ['ACTIVE_PACKAGE_NOT_APPROVED','CLICK_TARGET_NOT_FOUND','CLICK_TARGET_AMBIGUOUS','EDITABLE_AMBIGUOUS','SCROLLABLE_AMBIGUOUS','SWIPE_COORDINATE_OUT_OF_RANGE','UNKNOWN_GLOBAL_ACTION']:
    req(failure in svc, f'fail closed reason missing {failure}')

# confirmation semantics
req('"CONFIRMED" : "DISPATCHED"' in svc, 'confirmed/dispatched separation missing')
req('result_hash=' in sec and 'sha256String(result)' in sec, 'audit result hashing missing')
req('owner_audit.log' in sec, 'audit log persistence missing')

# no accidental vendor paywall/subscription bypass code
for bad in ['purchase-verifier','billingClient','is_settings_paywall_active','free_trial_enabled','trial_enabled','subscription','paywall']:
    req(bad.lower() not in (svc+prov+sec+client+main).lower(), f'vendor entitlement bypass surface found: {bad}')

# source sanity: basic brace balance and class names
for p in list((R/'core/src/main/java').rglob('*.java')) + list((R/'bridge/src/main/java').rglob('*.java')):
    t=p.read_text()
    req(t.count('{')==t.count('}'), f'brace imbalance: {p}')
    req('package ' in t, f'package declaration missing: {p}')

print('V4_STATIC_SECURITY=PASS')
print('OWNER_SESSION_TTL=PASS')
print('PACKAGE_SIGNER_ALLOWLIST=PASS')
print('SCREEN_READ_PASSWORD_REDACTION=PASS')
print('CLICK_TYPE_SCROLL_SWIPE_GLOBAL_LAUNCH_SURFACE=PASS')
print('DISPATCHED_NE_CONFIRMED=PASS')
print('VENDOR_PAYWALL_BYPASS_ABSENT=PASS')
print('NOTE=SOURCE_STATIC_ONLY; ANDROID_BUILD_AND_REAL_DEVICE_RUNTIME_NOT_PROVEN')
