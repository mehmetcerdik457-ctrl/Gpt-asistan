from pathlib import Path
R=Path(__file__).resolve().parents[1]
blob='\n'.join(p.read_text(errors='ignore') for p in R.rglob('*') if p.is_file() and p.suffix in {'.java','.xml','.gradle','.md','.txt','.py','.properties'})
for s in ['dispatchGesture','performGlobalAction','approved_package_signers','protectionLevel="signature"','verifyPostcondition','revokePackage']:
 assert s in blob, s
print('SOURCE_LEXICAL_TEST=PASS')
