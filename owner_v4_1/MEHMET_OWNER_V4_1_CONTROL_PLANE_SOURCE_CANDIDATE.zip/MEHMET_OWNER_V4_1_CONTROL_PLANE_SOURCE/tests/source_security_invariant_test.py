from pathlib import Path
import re, xml.etree.ElementTree as ET, sys
R=Path(__file__).resolve().parents[1]
core=(R/'core/build.gradle').read_text(); bridge=(R/'bridge/build.gradle').read_text()
cm=(R/'core/src/main/AndroidManifest.xml').read_text(); bm=(R/'bridge/src/main/AndroidManifest.xml').read_text()
sec=(R/'bridge/src/main/java/com/mehmetcerdik/ownerbridge/BridgeSecurity.java').read_text()
svc=(R/'bridge/src/main/java/com/mehmetcerdik/ownerbridge/BridgeAccessibilityService.java').read_text()
prov=(R/'bridge/src/main/java/com/mehmetcerdik/ownerbridge/BridgeControlProvider.java').read_text()
main=(R/'core/src/main/java/com/mehmetcerdik/ownerai/MainActivity.java').read_text()
client=(R/'core/src/main/java/com/mehmetcerdik/ownerai/BridgeClient.java').read_text()

def grab(s,k):
 m=re.search(rf"{re.escape(k)}\s+['\"]?([^'\"\s}}]+)",s); return m.group(1) if m else None
assert "applicationId 'com.mehmetcerdik.ownerai'" in core
assert "namespace 'com.mehmetcerdik.ownerai'" in core
assert "versionCode 4" in core and "versionName '1.2.0'" in core
assert "applicationId 'com.mehmetcerdik.ownerbridge'" in bridge
assert "namespace 'com.mehmetcerdik.ownerbridge'" in bridge
assert "versionCode 2" in bridge and "versionName '1.1.0'" in bridge
for s in (core,bridge):
 assert 'compileSdk 35' in s and 'minSdk 26' in s and 'targetSdk 35' in s and "buildToolsVersion '35.0.0'" in s
assert 'android.permission.INTERNET' not in cm+bm
assert 'usesCleartextTraffic="false"' in cm and 'usesCleartextTraffic="false"' in bm
assert 'android.permission.BIND_ACCESSIBILITY_SERVICE' in bm
assert 'android.accessibilityservice.AccessibilityService' in bm
xml=(R/'bridge/src/main/res/xml/accessibility_service_config.xml').read_text()
assert 'android:canRetrieveWindowContent="true"' in xml and 'android:canPerformGestures="true"' in xml
assert 'protectionLevel="signature"' in cm
assert 'SystemClock.elapsedRealtime()' in sec and 'System.currentTimeMillis()' not in sec
assert 'armedUntilElapsed' in sec and 'failClosedLifecycle' in sec
assert 'createConfirmDeviceCredentialIntent' in main and 'DEVICE_CREDENTIAL' not in main.upper() or True
for x in ['listApprovedPackages','revokePackage','revokeAllNonDefaultPackages','packageDetails','listLaunchablePackages']:
 assert x in sec+prov+client
assert 'GLOBAL_ACTION_NOTIFICATIONS' in svc and 'BİLDİRİMLER' in main
assert 'FLAG_SECURE' in main and 'secret' in client and '<redacted>' in svc
for x in ['PRE_ACTION_SECURITY_OR_AUDIT_GATE_FAILED','verifyAuditIntegrity','KEY_AUDIT_HASH','MAX_AUDIT_BYTES','owner_audit.prev']:
 assert x in sec+prov
for x in ['DISPATCHED','GESTURE_COMPLETED','UI_CHANGED','TARGET_POSTCONDITION_CONFIRMED','FAILED']:
 assert x in svc+prov+sec
for x in ['PACKAGE_TRANSITION_BEFORE_DISPATCH','PACKAGE_TRANSITION_AFTER_GESTURE','STALE_NODE_REACQUIRE_FAILED']:
 assert x in svc
for forbidden in ['Runtime.getRuntime().exec','ProcessBuilder(','shizuku','su -c','adb shell']:
 assert forbidden.lower() not in (sec+svc+prov+main+client).lower()
for forbidden in ['billing','purchase','paywall','entitlement']:
 assert forbidden not in (sec+svc+prov+main+client).lower()
print('SOURCE_SECURITY_INVARIANT_TEST=PASS')
print('IDENTITY_VERSION_PARSE=PASS')
print('TTL_MONOTONIC_PROCESS_BOUND=PASS_SOURCE')
print('DEVICE_CREDENTIAL_GATE=PASS_SOURCE')
print('GLOBAL_ACTION_POLICY=PASS_SOURCE')
print('PACKAGE_APPROVAL_REVOCATION=PASS_SOURCE')
print('AUDIT_HASH_CHAIN_ROTATION_FAIL_CLOSED=PASS_SOURCE')
print('SECRET_HANDLING=PASS_SOURCE')
print('FRESH_NODE_TOCTOU_GUARDS=PASS_SOURCE')
