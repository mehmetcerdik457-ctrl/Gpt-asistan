#!/usr/bin/env bash
set -euo pipefail
python3 tests/security_model_negative_test.py
