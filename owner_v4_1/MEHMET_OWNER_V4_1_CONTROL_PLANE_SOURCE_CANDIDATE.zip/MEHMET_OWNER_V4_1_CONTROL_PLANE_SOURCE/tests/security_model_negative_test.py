import hashlib

def h(s): return hashlib.sha256(s.encode()).hexdigest()
# audit tamper-evident model
entries=[]; prev='GENESIS'
for seq,action in enumerate(['ARM','PRE_CLICK','CLICK'],1):
    payload=f'seq={seq}|action={action}|prev={prev}'
    ent=h(payload); entries.append([payload,ent]); prev=ent

def verify(rows):
    exp='GENESIS'; seq=1
    for payload,ent in rows:
        if h(payload)!=ent: return False
        fields=dict(x.split('=',1) for x in payload.split('|'))
        if int(fields['seq'])!=seq or fields['prev']!=exp: return False
        exp=ent; seq+=1
    return True
assert verify(entries)
mut=[x[:] for x in entries]; mut[1][0]=mut[1][0].replace('PRE_CLICK','PRE_HOME'); assert not verify(mut)
assert not verify(entries[:1]+entries[2:])
mut=[entries[1],entries[0],entries[2]]; assert not verify(mut)
mut=[x[:] for x in entries]; mut[2][0]=mut[2][0].replace(entries[1][1],'0'*64); mut[2][1]=h(mut[2][0]); assert not verify(mut)
# secret classifier keyword model
keys=['password','parola','şifre','sifre','pin','otp','cvv','cvc','token','api key','apikey','recovery','kurtarma','seed','secret','gizli','verification code','doğrulama kod']
for s in ['password','PIN','OTP','CVV','API key','token','recovery code','seed phrase','gizli alan','doğrulama kodu']:
    assert any(k in s.lower() for k in keys), s
print('AUDIT_CORRUPTION_NEGATIVE_TEST=PASS_MODEL')
print('SECRET_CLASSIFIER_NEGATIVE_TEST=PASS_MODEL')
